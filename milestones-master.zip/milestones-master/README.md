# Milestones

Code sample for Online Rewards

## Installation

If you haven't already, please [install Elixir](https://elixir-lang.org/install.html).

Since you've already unzipped this archive, you'll need to pull down dependencies:
```
mix deps.get
```
Next, you'll want to build milestones as a stand-alone executable, per the requirements:
```
mix escript.build
```

## Tests

To run unit tests:
```
mix test
```

## Execution

To run, simply provide the path to the employee CSV file (included with this archive), along
with a "run date" for the report, in the ISO-8601 format, as command line arguments.
For example, running for 21 March 2019 on the included CSV would look like:

```
./milestones employee_data.csv 2019-03-21
```

The output will be an array of JSON objects, one for each employee along with the next 5
milestones amongst their direct reports. If an employee has no direct reports, then the
upcoming milestones will be an empty array/list. This output will be sent to stdout, so
pipe the data appropriately!