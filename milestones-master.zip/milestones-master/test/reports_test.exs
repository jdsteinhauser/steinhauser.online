defmodule ReportsTest do
  use ExUnit.Case

  test "increment 29 Feb as 28 Feb" do
    date = ~D[2016-02-29]
    actual = Reports.increment_date(date)

    assert Date.compare(actual, ~D[2021-02-28]) == :eq
  end

  test "return @output_milestones after report date" do
    test_record = EmployeeRecord.from_csv("lvelasquez222,Lois,Velasquez,1977-04-09,rhardy213")
    date = ~D[2019-03-21]
    actual = Reports.calc_milestones(test_record, date)
    
    assert Date.compare(hd(actual).date, ~D[2022-04-09]) == :eq
    assert Enum.count(actual) == 5
    assert Enum.all?(actual, fn record -> Date.compare(record.date, date) != :lt end)
  end

  test "milestone dates do not include hire date" do
    test_record = EmployeeRecord.from_csv("lvelasquez222,Lois,Velasquez,1977-04-09,rhardy213")
    date = ~D[2019-03-21]
    actual = Reports.calc_milestones(test_record, date)

    refute Enum.any?(actual, fn record -> Date.compare(record.date, test_record.date) == :eq end)
  end
end
