defmodule Reports do

  # Max number of milestones required in spec
  @output_milestones 5
  # Years in between milestones as specified in spec
  @anniversary_increment 5

  def increment_date(date = %Date{:month => 2, :day => 29}), do:  increment_date(%{date | day: 28})

  def increment_date(date = %Date{}), do: %{date | year: date.year + @anniversary_increment}

  def calc_milestones(record, date) do
    record.date
    |> Stream.iterate(&increment_date/1)
    |> Stream.drop(1)                                                  # We don't want to include the hire date
    |> Stream.drop_while(fn d -> (Date.compare(d, date) == :lt) end)   # Drop any before the report date
    |> Enum.take(@output_milestones)                                   # We will need, at most, 5 records
    |> Enum.map(fn date -> Map.put(record, :date, date) end)
  end

  defp stylize({supervisor_id, milestone_records}) do
    milestones =
      milestone_records
      |> Enum.map(fn rec -> %{employee_id: rec.employee_id, anniversary_date: rec.date} end)

    %{supervisor_id: supervisor_id, upcoming_milestones: milestones}
  end

  def generate_milestones(employee_records, date) do

    # We're going to group all records by supervisor, then merge with an empty map of all employee IDs
    employee_records
    |> Enum.flat_map(fn record -> calc_milestones(record, date) end)
    |> Enum.group_by(&(&1.supervisor_id))
    |> Enum.map(fn {k,v} -> {k, Enum.sort_by(v, fn x -> x.date end, fn x, y -> Date.compare(x, y) == :lt end)} end)
    |> Enum.map(fn {k,v} -> {k, Enum.take(v,@output_milestones)} end)
    |> Map.new()
    |> Map.merge(Map.new(employee_records, fn rec -> {rec.employee_id, []} end), fn _k, v1, _v2 -> v1 end)
    |> Enum.map(&stylize/1)
  end
end