defmodule Milestones.CLI do
  @moduledoc """
  Documentation for Milestones CLI.
  """

  @doc """
  Application entry point. Takes as command line args:
  - Name of a CSV file formatted as such:
    `employee_id,first_name,last_name,hire_date,supervisor_id`
  - Date for which to run the milestone report formatted as YYYY-MM-DD

  This utility will output a JSON object to stdout of each supervisor's
  next (at most) 5 milestones, with a milestone being defined as every
  fifth anniversary of an employee's hiring date.
  """
  def main([filename, date]) do
    filename
    |> File.stream!()
    |> Enum.drop(1)   # drop the header line
    |> Enum.map(&String.trim/1)
    |> Enum.map(&EmployeeRecord.from_csv/1)
    |> Reports.generate_milestones(Date.from_iso8601!(date))
    |> Jason.encode!()
    |> IO.puts()
  end

end
