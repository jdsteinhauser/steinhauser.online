defmodule EmployeeRecord do
  defstruct [:employee_id, :first_name, :last_name, :date, :supervisor_id]

  def from_csv(line) do
    [id, first, last, hire_date, supervisor] = String.split(line, ",")
    %EmployeeRecord{
      employee_id: id,
      first_name: first,
      last_name: last,
      date: Date.from_iso8601!(hire_date),
      supervisor_id: supervisor
    }
  end
end